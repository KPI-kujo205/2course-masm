\masm32\bin\ml /c /coff "8-12-IM-21-Kryvokhata-static-entry-proc.asm"
\masm32\bin\link32.exe /out:"8-12-IM-21-Kryvokhata-static-entry-proc.dll" /def:"8-12-IM-21-Kryvokhata-static-entry.def" /dll /entry:lab8_entry_pnt "8-12-IM-21-Kryvokhata-static-entry-proc.obj"
\masm32\bin\ml /c /coff "8-12-IM-21-Kryvokhata-static-entry-prog.asm"
\masm32\bin\link32.exe /subsystem:windows "8-12-IM-21-Kryvokhata-static-entry-prog.obj"	
8-12-IM-21-Kryvokhata-static-entry-prog.exe
