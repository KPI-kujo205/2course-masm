.386
.model flat, stdcall
option casemap:none

.code

lab8_entry_pnt proc hInstDLL:DWORD, reason:DWORD, unused:DWORD
   mov eax, 1
   ret
lab8_entry_pnt endp


lab8_calculate_proc proc dataset_d_values: ptr qword, dataset_c_values: ptr qword, dataset_b_values: ptr qword, dataset_a_values: ptr qword,
task_const_1: ptr qword, task_const_2: ptr qword, task_const_25: ptr qword, final_calc_result: ptr qword, global_znamennyk: ptr tbyte, global_chyselnyk: ptr tbyte, value_in_root: ptr tbyte
  finit
  ;; calculating znamennyk
  mov esi, dataset_b_values
  fld qword ptr [esi]
  mov ebx, dataset_a_values
  fadd qword ptr [ebx]            ; b + a
  mov edx, task_const_1
  fsub qword ptr [edx]            ; b + a - 1

  mov ecx, global_znamennyk       ; store result in global_znamennyk
  fstp tbyte ptr [ecx] 

  ;; calculating chyselnyk
  mov esi, task_const_25
  fld qword ptr [esi]
  mov ebx, dataset_c_values
  fdiv qword ptr [ebx]            ; 25/c     
                        
  mov ecx, value_in_root
  fstp tbyte ptr [ecx]            ; save the value which will be in square 

  fld tbyte ptr [ecx]
  fsqrt                           ; sqrt(25/c)       

  mov esi, dataset_d_values
  fld qword ptr [esi]
  fsub                            ; sqrt(25/c) - d
  mov ebx, task_const_2
  fadd qword ptr [ebx]            ; sqrt(25/c) - d + 2
  
  mov ecx, global_chyselnyk       ; save chyselnyk
  fstp tbyte ptr [ecx]

  ;; dividing chyselnyk by znamennyk
  fld tbyte ptr [ecx] 
  mov edx, global_znamennyk
  fld tbyte ptr [edx]
  fdiv

  ; putting the final result in final_calc_result
  mov ecx, final_calc_result
  fstp qword ptr [ecx]
  
  ret 62                         
lab8_calculate_proc endp
end lab8_entry_pnt
