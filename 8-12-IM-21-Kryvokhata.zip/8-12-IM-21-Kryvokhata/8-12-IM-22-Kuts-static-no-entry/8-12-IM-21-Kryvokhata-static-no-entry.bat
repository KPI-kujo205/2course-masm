\masm32\bin\ml /c /coff "8-12-IM-21-Kryvokhata-static-no-entry-proc.asm"
\masm32\bin\link32.exe /out:"8-12-IM-21-Kryvokhata-static-no-entry-proc.dll" /def:"8-12-IM-21-Kryvokhata-static-no-entry.def" /dll /noentry "8-12-IM-21-Kryvokhata-static-no-entry-proc.obj"
\masm32\bin\ml /c /coff "8-12-IM-21-Kryvokhata-static-no-entry-prog.asm"
\masm32\bin\link32.exe /subsystem:windows "8-12-IM-21-Kryvokhata-static-no-entry-prog.obj"	
8-12-IM-21-Kryvokhata-static-no-entry-prog.exe