; prog

.386
.model flat, stdcall
option casemap:none

include \masm32\include\windows.inc      ; MB_OK
include \masm32\include\user32.inc
include \masm32\include\kernel32.inc
include \masm32\include\masm32.inc

includelib \masm32\lib\user32.lib        ; wsprintf, MessageBox
includelib \masm32\lib\kernel32.lib      ; LoadLibrary,  GetProcAddress, FreeLibrary, ExitProcess
includelib \masm32\lib\masm32.lib        ; FloatToStr, FloatToStr2

.data?

lib dd ?
lib_addr dd ?

all_wnd_correct_data db 256 dup(?)
all_wnd_wrong_zero_data db 256 dup(?)
all_wnd_wrong_root_data db 256 dup(?)

value_in_root dt 32 dup(?)
global_chyselnyk dt 32 dup(?)
global_znamennyk dt 32 dup(?)

final_calc_result dq 32 dup(?)

a_value_str db 64 dup(?)
b_value_str db 64 dup(?)
c_value_str db 64 dup(?)
d_value_str db 64 dup(?)
final_calc_result_str db 64 dup(?)

.data

my_dynamic_lib db "8-12-IM-22-Kuts-implicit-no-entry-proc", 0
name_of_proc db "lab8_calculate_proc", 0

dataset_a_values dq 0.333, 1.55, 0.45, 5.7, 3.48, 3.42
dataset_b_values dq 8.96, -2.25, 3.97, -4.7, -5.78, 1.75
dataset_c_values dq 7.34, 6.5, 4.5, 2.54, 8.45, -4.51
dataset_d_values dq 0.47, -0.9, 9.85, 6.8, 6.54, 3.53

task_const_25 dq 25.0
task_const_2 dq 2.0
task_const_1 dq 1.0

wnd_msg_correct_title db "With 'includelib', without entry", 0
wnd_msg_wrong_title db "Something went wrong!", 0

wnd_msg_correct_template db "Number in the group list: 12", 13, 10
                 db "The general task is: (sqrt(25/c) - d + 2) / (b + a - 1)", 13, 10
                 db "The data is: a=%s, b=%s, c=%s, d=%s", 13, 10
                 db "Task with provided data: (sqrt(25/%s) - %s + 2) / (%s + %s - 1)", 13, 10
                 db "Result: %s", 0

wnd_msg_wrong_zero_template db "Number in the group list: 12", 13, 10
                 db "The general task is: (sqrt(25/c) - d + 2) / (b + a - 1)", 13, 10
                 db "The data is: a=%s, b=%s, c=%s, d=%s", 13, 10
                 db "Task with provided data: (sqrt(25/%s) - %s + 2) / (%s + %s - 1)", 13, 10, 13, 10
                 db "It is impossible to divide by 0!!! Try input another dataset", 0

wnd_msg_wrong_root_template db "Number in the group list: 12", 13, 10
                 db "The general task is: (sqrt(25/c) - d + 2) / (b + a - 1)", 13, 10
                 db "The data is: a=%s, b=%s, c=%s, d=%s", 13, 10
                 db "Task with provided data: (sqrt(25/%s) - %s + 2) / (%s + %s - 1)", 13, 10, 13, 10
                 db "The value in square root must be greater than 0!!! Try input another dataset", 0

.code

check_exception_value macro needed_value
    fld needed_value
    ftst
    fstsw ax
    sahf
endm

KryvokhataLab8:

xor edi, edi
.while edi < 6
    invoke LoadLibrary, addr my_dynamic_lib
    mov lib, eax 
    invoke GetProcAddress, lib, addr name_of_proc
    mov lib_addr, eax
  
    ;; convert all float data to strings
    invoke FloatToStr, dataset_a_values[edi * 8], addr a_value_str
    invoke FloatToStr, dataset_b_values[edi * 8], addr b_value_str
    invoke FloatToStr, dataset_c_values[edi * 8], addr c_value_str
    invoke FloatToStr, dataset_d_values[edi * 8], addr d_value_str

    finit

    push offset value_in_root
    push offset global_chyselnyk
    push offset global_znamennyk
    push offset final_calc_result
    push offset task_const_25
    push offset task_const_2
    push offset task_const_1

    lea ebx, dataset_a_values[edi * 8]
    push ebx
    lea edx, dataset_b_values[edi * 8]
    push edx
    lea ecx, dataset_c_values[edi * 8]
    push ecx
    lea esi, dataset_d_values[edi * 8]
    push esi

    call [lib_addr]

    ;; check if znamennyk=0
    check_exception_value global_znamennyk
    jz zero_division                                ; jump to error message in case of division by zero

    ;; check whether value in root is less than 0
    check_exception_value value_in_root
    jb minus_in_square_root

    successful_msg:                                 ; successful display of data
    invoke FloatToStr2, final_calc_result, addr final_calc_result_str
    invoke wsprintf, addr all_wnd_correct_data, addr wnd_msg_correct_template,
                     addr a_value_str, addr b_value_str, addr c_value_str, addr d_value_str,
                     addr c_value_str, addr d_value_str, addr b_value_str, addr a_value_str,
                     addr final_calc_result_str
    push MB_OK
    push offset wnd_msg_correct_title
    push offset all_wnd_correct_data
    push 0           
    call MessageBox
    jmp continue_while

    zero_division:                                  ; znamennyk is zero. telling about an error
    invoke wsprintf, addr all_wnd_wrong_zero_data, addr wnd_msg_wrong_zero_template,
                     addr a_value_str, addr b_value_str, addr c_value_str, addr d_value_str,
                     addr c_value_str, addr d_value_str, addr b_value_str, addr a_value_str
    push MB_OK
    push offset wnd_msg_wrong_title
    push offset all_wnd_wrong_zero_data
    push 0           
    call MessageBox
    jmp continue_while

    minus_in_square_root:                           ; negative value in square root. telling about an error
    invoke wsprintf, addr all_wnd_wrong_root_data, addr wnd_msg_wrong_root_template,
                     addr a_value_str, addr b_value_str, addr c_value_str, addr d_value_str,
                     addr c_value_str, addr d_value_str, addr b_value_str, addr a_value_str
    push 0
    push offset wnd_msg_wrong_title
    push offset all_wnd_wrong_root_data
    push 0           
    call MessageBox
    jmp continue_while

    continue_while:                
    inc edi
.endw

invoke FreeLibrary, lib
invoke ExitProcess, 0

end KryvokhataLab8


